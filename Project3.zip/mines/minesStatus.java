package mines;
import gridgame.*;


/**
 * Write a description of class minesStatus here.
 * 
 * @author Mark Lerner
 * @version Nov 8
 */
public class minesStatus extends GridStatus
{
    
}
