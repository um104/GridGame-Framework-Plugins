package mines;


/**
 * Enumeration class Piece - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Piece
{
        bomb,
        empty,
        exploded,
        flagged,
        hidden;
    }
