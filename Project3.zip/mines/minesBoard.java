package mines;
import gridgame.*;


/**
 * Write a description of class minesBoard here.
 * 
 * @author Mark Lerner 
 * @version Nov 8
 */
public class minesBoard extends GridBoard<minesCell>
{
    public minesBoard()
    { 
        resetBoard();
    }
    
    public void resetBoard()
    {
        int size;
        if(parent == null || parent.getPreference("Board Size") == null)
            size = 8;
        else
            size = Integer.parseInt(parent.getPreference("Board Size"));
        
        grid = new minesCell[size][size];
        
        for(int row = 0; row < size; row++)
        {
            for(int col = 0; col < size; col++)
            {
                grid[row][col] = new minesCell(Piece.hidden);
            }
        }
    }
}
