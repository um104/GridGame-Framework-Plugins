package mines;
import gridgame.*;


/**
 * Write a description of class MinesStatus here.
 * 
 * @author Mark Lerner
 * @version Nov 8
 */
public class MinesStatus extends GridStatus
{
    
}
