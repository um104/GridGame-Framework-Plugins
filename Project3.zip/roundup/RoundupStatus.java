package roundup;
import gridgame.*;


/**
 * Write a description of class RoundupStatus here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RoundupStatus extends GridStatus
{
}
