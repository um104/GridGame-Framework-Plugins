package roundup;


/**
 * Enumeration class Imgs 
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Imgs
{
    deaddown, deadleft, deadright, deadup,
    dot, empty,
    greendown, greenleft, greenright, greenup,
    reddown, redleft, redright, redup;
}
