package mahjongg;

import gridgame.*;
import java.util.*;

/**
 * Write a description of class mahjonggBoard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mahjonggBoard extends GridBoard<mahjonggCell>
{
   
    public mahjonggBoard()
    {
        resetBoard();
    }
    
    public void resetBoard()
    {
        int[] ranks = {1, 2, 3, 4, 5, 6, 7};
        ArrayList<mahjonggCell> cellList = new ArrayList<mahjonggCell>();
        
        for(int rank : ranks)
        {
            for(Suits suit : Suits.values())
            {
                cellList.add(new mahjonggCell(suit, rank));
                cellList.add(new mahjonggCell(suit, rank));
                cellList.add(new mahjonggCell(suit, rank));
                cellList.add(new mahjonggCell(suit, rank));
            }
        }
        
        Random generator;
        if(parent == null)
            generator = new Random(0);
        else
            generator = new Random(parent.getGame());
        Collections.shuffle(cellList, generator);
        
        grid = new mahjonggCell[8][12];
        int[] cols = {12, 8, 10, 12, 12, 10, 8, 12};
        int buffer = 0;
        
        for(int row = 0; row < 8; row++)
        {
            if(cols[row] < 12)
            {
                //find out how much less it is than twelve, then divide that by two. set that as the buffer.
                buffer = (12-cols[row])/2;
                //add a null value to myBoard for every buffer space
                for(int i=0;i<buffer;i++)
                {   grid[row][i] = new mahjonggCell(Suits.B, 0); }
            }
            for(int col = 0; col < cols[row]; col++)
            {
                grid[row][col + buffer] = cellList.remove(0);
            }
            for(int i=0;i<buffer;i++)
            {   grid[row][i + cols[row] + buffer] = new mahjonggCell(Suits.B, 0); }
            buffer = 0;
        }
    }
    
    public void setCell(int row, int col, mahjonggCell cell)
    {
        //check bounds
        if(row < 0 || row > 7 || col < 0 || col > 11)
        {
            return;
        }
        
        grid[row][col] = cell;
    }
}
