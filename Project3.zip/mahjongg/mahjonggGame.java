package mahjongg;

import gridgame.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * Write a description of class mahjonggGame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mahjonggGame extends GridGame
{
    // instance variables - replace the example below with your own
    private mahjonggBoard board;
    private mahjonggStatus status;
    private TimerLabel timer;
    
    private mahjonggCell selected = null;
    private int selectedRow = 0;
    private int selectedCol = 0;
    private int tilesLeft = 0;

    /**
     * Constructor for objects of class mahjonggGame
     */
    public mahjonggGame(GridBoard board, GridStatus status)
    {
        this.board = (mahjonggBoard)board;
        this.status = (mahjonggStatus)status;
        setGame(1);
    }
    
    public GridBoard getBoardToView()
    {
        return board;
    }
    
    public GridStatus getStatusToView()
    {
        return status;
    }
    
    public void init()
    {
        if(timer == null)
            timer = new TimerLabel();
        else
            timer.restart();

        status.setAttributes(timer);
        status.add(timer);
        tilesLeft = 84;
        selected = null;
        selectedRow = 0;
        selectedCol = 0;
        
        board.resetBoard();
        
        updateStatus();
        setChanged();
        notifyObservers(new Integer(getGame()));
    }
    
    public void restart()
    {
        init();
    }
    
    public void makeMove(int row, int col)
    {
        if(((mahjonggCell)board.getValueAt(row, col)).getRank() != 0)
        {
            if((col != 0) && (col != 11) && ((mahjonggCell)board.getValueAt(row,col-1)).getRank() != 0 && ((mahjonggCell)board.getValueAt(row,col+1)).getRank() != 0)
                {
                    selected = null;
                }
                else if((selected != null) && selected.equals(board.getValueAt(row,col)) && selected != board.getValueAt(row,col))
                {
                    board.setCell(row,col,new mahjonggCell(Suits.B, 0));
                    board.setCell(selectedRow,selectedCol,new mahjonggCell(Suits.B, 0));
                    tilesLeft = tilesLeft - 2;
                    updateStatus();
                    if(tilesLeft == 0)
                    {
                        winning();
                    }
                    selected = null;
                }
                else
                {
                    selected = (mahjonggCell) board.getValueAt(row,col);
                    selectedRow = row;
                    selectedCol = col;
                }
        }
        
        setChanged();
        notifyObservers();
    }
    
    private void winning()
    {
        timer.pause();
        
        JOptionPane.showMessageDialog(null, "You win!", "Message", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void updateStatus()
    {status.setLabelText("Tiles Left: " + tilesLeft +  "   ");
    }
    
    public java.util.List<javax.swing.Action> getMenuActions()
    {
        ArrayList<javax.swing.Action> retlist = new ArrayList<javax.swing.Action>();
        
        retlist.add(new AbstractAction("Restart") {
            public void actionPerformed(ActionEvent e)
            {
                restart();
            }
        });
        
        retlist.add(new AbstractAction("New Game") {
            public void actionPerformed(ActionEvent e)
            {
                incrementGame();
                restart();
            }
        });
        
        retlist.add(new AbstractAction("Hint") {
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(null, "Hint: " + movesLeft(), "Message", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        retlist.add(new AbstractAction("Cheat") {
            public void actionPerformed(ActionEvent e)
            {
                tilesLeft = 2;
                updateStatus();
                
                for(int row = 0; row < 8; row++)
                {
                    for(int col = 0; col < 12; col++)
                    {
                        board.setCell(row,col,new mahjonggCell(Suits.B, 0));
                    }
                    board.setCell(3,5, new mahjonggCell(Suits.B, 1));
                    board.setCell(3,6, new mahjonggCell(Suits.B, 1));
                    
                    setChanged();
                    notifyObservers();
                }
            }
        });
        
        retlist.add(new AbstractAction("Quit") {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        });
        
        return retlist;
    }
    
    private String movesLeft()
    {
        ArrayList<mahjonggCell> list = new ArrayList<mahjonggCell>();
        for(int row = 0; row < 8; row++)
        {
            for(int col = 0; col < 12; col++)
            {
                if(((mahjonggCell)board.getValueAt(row, col)).getRank() != 0)
                {
                    if((col == 0) || (col == 11) || ((mahjonggCell)board.getValueAt(row,col-1)).getRank() == 0 || ((mahjonggCell)board.getValueAt(row,col+1)).getRank() == 0)
                    {
                        if(list.contains((mahjonggCell)board.getValueAt(row,col)))
                        {
                            return ((mahjonggCell)board.getValueAt(row,col)).toString();
                        }
                        list.add((mahjonggCell)board.getValueAt(row,col));
                    }
                }
            }
        }
        
        return "No moves available.";
    }
}
