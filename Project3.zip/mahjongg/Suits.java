package mahjongg;


/**
 * Enumeration class Suits
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Suits
{
    B, C, D;
}
