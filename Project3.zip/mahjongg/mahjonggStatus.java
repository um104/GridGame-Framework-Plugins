package mahjongg;

import gridgame.*;

/**
 * Write a description of class mahjonggStatus here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mahjonggStatus extends GridStatus
{
   
}
